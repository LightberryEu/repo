# plugin.program.hyperion.screenshot

This is KODI plugin, that helps taking screenshot from a grabber and displays it on TV.

See [our blog post](http://raspberry-at-home.com/kodi-plugin-hyperion-configurator/) for detailed tutorial.

Visit lightberry.eu for cool, easy to use hardware.

Lightberry Team

TODO:
- other OSes than OpenELEC
